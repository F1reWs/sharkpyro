from setuptools import setup

setup(
    name='sharkpyro',
    version='1.4.3',
    description='Pyrogram fork for SharkUserBot',
    author="Dan",
    author_email="dan@pyrogram.org",
    packages=['sharkpyro'],
    install_requires=[
        'tgcrypto',
    ],
)
